## MusicBox

MusicBox - A online web music player built using HTML, CSS, Javascript and Django

## Tech Stack

-   HTML, CSS, Javascript
-   Django

## Installation

1. Clone the repository
2. Install the requirements
3. Run the server (python manage.py runserver)

## Usage

1. Open the browser
2. Go to the URL: http://localhost:8000
3. Play the music
